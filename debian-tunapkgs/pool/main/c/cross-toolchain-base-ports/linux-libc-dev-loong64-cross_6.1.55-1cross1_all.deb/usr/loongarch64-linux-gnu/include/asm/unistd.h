/* SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note */
#define __ARCH_WANT_SYS_CLONE
#define __ARCH_WANT_SYS_CLONE3

#include <asm-generic/unistd.h>
