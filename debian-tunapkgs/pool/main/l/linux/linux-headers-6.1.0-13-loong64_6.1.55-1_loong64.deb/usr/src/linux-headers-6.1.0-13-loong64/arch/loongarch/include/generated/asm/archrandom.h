#include <asm-generic/archrandom.h>
