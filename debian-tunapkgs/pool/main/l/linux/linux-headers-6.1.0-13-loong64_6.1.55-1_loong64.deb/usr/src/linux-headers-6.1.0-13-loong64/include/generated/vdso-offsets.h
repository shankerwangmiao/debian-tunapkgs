#define vdso_offset_sigreturn	0x05e0
