#define UTS_MACHINE		"loongarch64"
#define LINUX_COMPILE_BY	"debian-kernel"
#define LINUX_COMPILE_HOST	"lists.debian.org"
#define LINUX_COMPILER		"loongarch64-linux-gnu-gcc-12 (Debian 12.2.0-14) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40"
