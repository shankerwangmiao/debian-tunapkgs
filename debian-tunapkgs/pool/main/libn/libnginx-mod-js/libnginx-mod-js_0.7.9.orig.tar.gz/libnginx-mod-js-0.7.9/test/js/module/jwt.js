var jwt = {};

jwt.verify = function() {
    return "JWT-OK";
}

export default jwt;
