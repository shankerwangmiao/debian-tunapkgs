/*---
includes: []
flags: []
paths: [test/js/module, test/js/module/libs]
negative:
  phase: runtime
---*/

import m from 'ref_exception.js';
