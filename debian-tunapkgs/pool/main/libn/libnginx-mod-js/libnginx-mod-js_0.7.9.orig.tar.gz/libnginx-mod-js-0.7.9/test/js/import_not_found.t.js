/*---
includes: []
flags: []
njs_cmd_args: []
negative:
  phase: runtime
---*/

import name   from 'name.js';
