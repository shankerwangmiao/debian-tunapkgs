/*---
includes: []
flags: []
paths: [test/js/module/]
---*/

import _ from 'function_expression.js';
