
/*
 * Copyright (C) Alexander Borisov
 * Copyright (C) NGINX, Inc.
 */

#ifndef _NJS_ENCODING_H_INCLUDED_
#define _NJS_ENCODING_H_INCLUDED_

extern const njs_object_type_init_t  njs_text_encoder_type_init;
extern const njs_object_type_init_t  njs_text_decoder_type_init;


#endif /* _NJS_ENCODING_H_INCLUDED_ */
